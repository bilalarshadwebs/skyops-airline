# SkyOps – Airline Operations (Python + HTML + JSON)

1. pip install -r requirements.txt
2. python app.py
3. Open http://localhost:5000

All data is saved in data.json (created on first run with demo data).
airline_model.py is your original class file; the "Run model demo" tab executes its main().

## Deploy on Render (free web service)

- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Runtime: Python 3

For GitHub, upload the contents of this `airline` folder to the repository root (so `app.py` and `requirements.txt` are at the top level).

Note: this demo currently stores data in a local `data.json` file. On Render's free web service, local filesystem changes are not persistent across restarts/redeploys, so use it for a presentation demo and keep a local backup.
